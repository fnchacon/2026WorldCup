# How to publish this to your GitHub

You'll do this part yourself (I'm not connected to your GitHub). Takes ~2 minutes.

## 1. Create an empty public repo
Go to https://github.com/new
- Repository name: `world_cup_2026` (or whatever you like)
- Public
- Do NOT initialize with a README (this folder already has one)

## 2. From this folder, run:
```bash
cd world_cup_2026
git init
git add .
git commit -m "Recency-weighted Dixon-Coles WC2026 model (Claude Opus 4.8 x @fnchacon)"
git branch -M main
git remote add origin https://github.com/fnchacon/world_cup_2026.git
git push -u origin main
```

## 3. (Optional) Before pushing
- Fill in `predictions/bracket_vs_model_TEMPLATE.csv` with your actual bracket
  picks so the "accountability ledger" has real numbers, then rename it to
  `bracket_vs_model.csv` and update the README link.
- Drop a chart into `figures/` (e.g. the title-odds bar chart) and reference it
  in the README for visual punch — readers love a hero image.

## Note on co-authoring with an AI
GitHub has no formal "AI co-author" field, but you can preserve the attribution
in commit trailers if you like:
```
git commit -m "..." -m "Co-authored-by: Claude Opus 4.8 <noreply@anthropic.com>"
```
Entirely your call on framing.
